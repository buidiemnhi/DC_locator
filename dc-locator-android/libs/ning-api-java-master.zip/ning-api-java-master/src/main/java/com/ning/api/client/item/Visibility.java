package com.ning.api.client.item;

public enum Visibility
{
    all, members, friends, me;
}
