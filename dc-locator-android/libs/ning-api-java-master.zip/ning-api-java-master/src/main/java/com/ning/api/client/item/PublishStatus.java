package com.ning.api.client.item;

public enum PublishStatus
{
    publish,
    draft,
    queued;
}
