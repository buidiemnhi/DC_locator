package com.ning.api.client.http;

public class NingHttpDelete extends NingHttpRequest<NingHttpDelete>
{
    public NingHttpDelete(NingRequestBuilder<?> requestBuilder)
    {
        super(requestBuilder);
    }
}
