package com.ning.api.client.http;

public class NingHttpGet
    extends NingHttpRequest<NingHttpGet>
{
    public NingHttpGet(NingRequestBuilder<?> requestBuilder)
    {
        super(requestBuilder);
    }
}
