package com.ning.api.client.item;

public enum FriendState {
    friend, friend_request, follower, pending, blocked_friend, blocked_follower;
}
